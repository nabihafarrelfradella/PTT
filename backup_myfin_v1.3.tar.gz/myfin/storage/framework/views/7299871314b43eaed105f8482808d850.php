<?php $__env->startSection('title', 'Riwayat Belanja'); ?>
<?php $__env->startSection('header_title', 'Riwayat Belanja Kantin'); ?>
<?php $__env->startSection('header_subtitle', 'Daftar lengkap seluruh transaksi pembayaran biometrik Anda di Kantin PSDKU'); ?>

<?php $__env->startSection('content'); ?>
<!-- Ringkasan Statistik Belanja -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
    <div style="background: #ffffff; border: 1px solid var(--border-color); border-radius: 12px; padding: 1.25rem;">
        <span style="font-size: 0.8rem; color: var(--text-muted);">Total Belanja Berhasil</span>
        <h3 style="font-size: 1.4rem; color: var(--primary-color); margin-top: 4px;">
            Rp <?php echo e(number_format($transactions->where('status', 'success')->sum('total_amount'), 0, ',', '.')); ?>

        </h3>
    </div>
    <div style="background: #ffffff; border: 1px solid var(--border-color); border-radius: 12px; padding: 1.25rem;">
        <span style="font-size: 0.8rem; color: var(--text-muted);">Jumlah Transaksi</span>
        <h3 style="font-size: 1.4rem; color: var(--primary-color); margin-top: 4px;">
            <?php echo e($transactions->count()); ?> Kali
        </h3>
    </div>
    <div style="background: #ffffff; border: 1px solid var(--border-color); border-radius: 12px; padding: 1.25rem;">
        <span style="font-size: 0.8rem; color: var(--text-muted);">Metode Pembayaran Utama</span>
        <h3 style="font-size: 1.4rem; color: <?php echo e(($debit && $debit->is_active) ? 'var(--accent-color)' : 'var(--text-muted)'); ?>; margin-top: 4px;">
            <?php echo e(($debit && $debit->is_active) ? $debit->bank_name : '-'); ?>

        </h3>
    </div>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Kode Transaksi</th>
                <th>Stand / Merchant</th>
                <th>Rincian Item</th>
                <th>Total</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td style="white-space: nowrap;"><?php echo e($tx->created_at->format('d M Y, H:i')); ?></td>
                <td style="white-space: nowrap;"><?php echo e($tx->transaction_code); ?></td>
                <td style="white-space: nowrap;"><?php echo e($tx->kantin->nama_kantin ?? 'Kantin PSDKU'); ?></td>
                <td style="font-size: 0.85rem; color: var(--text-muted);">
                    <?php if($tx->details->count() > 0): ?>
                        <?php $__currentLoopData = $tx->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($item->menu->nama_menu ?? 'Menu'); ?> (x<?php echo e($item->qty); ?>)</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td style="font-weight: 600; white-space: nowrap;">Rp <?php echo e(number_format($tx->total_amount, 0, ',', '.')); ?></td>
                <td style="white-space: nowrap;">
                    <?php if($tx->status === 'success'): ?>
                        <span class="status-badge active">Berhasil</span>
                    <?php elseif($tx->status === 'pending'): ?>
                        <span class="status-badge pending">Menunggu</span>
                    <?php elseif($tx->status === 'cancelled'): ?>
                        <span class="status-badge" style="background: #f1f5f9; color: #64748b; border: 1px solid #cbd5e1;">Dibatalkan</span>
                    <?php else: ?>
                        <span class="status-badge danger">Gagal</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 3rem;">
                    Belum ada riwayat transaksi belanja yang tercatat.
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/myfin/resources/views/mahasiswa/riwayat.blade.php ENDPATH**/ ?>