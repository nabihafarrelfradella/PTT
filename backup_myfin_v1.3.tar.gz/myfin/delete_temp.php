<?php
require '/var/www/myfin/vendor/autoload.php';
$app = require_once '/var/www/myfin/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use App\Models\Biometric;
use App\Models\DebitAccount;
use App\Models\Transaction;

$users = User::whereIn('id', [4, 5])->orWhereIn('email', ['siti@student.com', 'fahmi@gmail.com'])->get();

echo "User yang ditemukan: " . $users->pluck('name')->implode(', ') . PHP_EOL;

foreach ($users as $u) {
    echo "Menghapus data user: {$u->name} (ID: {$u->id})..." . PHP_EOL;
    
    // 1. Biometric
    $bCount = Biometric::where('user_id', $u->id)->delete();
    echo " - Biometric record terhapus: {$bCount}" . PHP_EOL;
    
    // 2. Debit Account
    $dCount = DebitAccount::where('user_id', $u->id)->delete();
    echo " - DebitAccount terhapus: {$dCount}" . PHP_EOL;
    
    // 3. Transactions (Set student_id to null agar riwayat penjualan kantin tidak corrupt)
    $tCount = Transaction::where('student_id', $u->id)->update(['student_id' => null]);
    echo " - Transaksi kantin di-unlink: {$tCount}" . PHP_EOL;
    
    // 4. User
    $u->delete();
    echo " - User {$u->name} berhasil dihapus permanen!" . PHP_EOL;
}

echo "=== DAFTAR USER AKTIF SETELAH PENGHAPUSAN ===" . PHP_EOL;
$remaining = User::all(['id', 'name', 'email', 'role']);
echo json_encode($remaining, JSON_PRETTY_PRINT) . PHP_EOL;
