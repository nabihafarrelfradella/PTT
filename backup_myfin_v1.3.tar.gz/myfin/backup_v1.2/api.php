<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BiometricController;

/*
|--------------------------------------------------------------------------
| API Routes for MyFin (Midtrans & AS608 IoT Biometric)
|--------------------------------------------------------------------------
*/

// Endpoint IoT ESP32 (Sensor Sidik Jari AS608 & Polling Dua Arah)
Route::get('/esp32/status', [BiometricController::class, 'devicePoll']);
Route::get('/esp32/device-status', [BiometricController::class, 'getDeviceStatus']);
Route::post('/esp32/transaksi', [BiometricController::class, 'verify']);
Route::post('/biometric/register', [BiometricController::class, 'register']);
Route::post('/biometric/verify', [BiometricController::class, 'verify']);

// Endpoint Real-Time Biometric Enrollment (Web <-> ESP32)
Route::post('/biometric/start-enroll', [BiometricController::class, 'startEnroll']);
Route::post('/biometric/enroll-finish', [BiometricController::class, 'enrollFinish']);
Route::post('/biometric/enroll-progress', [BiometricController::class, 'enrollProgress']);
Route::get('/biometric/enroll-status', [BiometricController::class, 'enrollStatus']);
Route::post('/biometric/cancel-enroll', [BiometricController::class, 'cancelEnroll']);

// Endpoint Kios POS Tablet
Route::post('/kios/checkout', [BiometricController::class, 'createKiosOrder']);
Route::post('/kios/cancel', [BiometricController::class, 'cancelKiosOrder']);
Route::get('/kios/order-status/{orderId}', [BiometricController::class, 'getKiosOrderStatus']);
Route::get('/kios/stream-order-status/{orderId}', [BiometricController::class, 'streamKiosOrderStatus']);
Route::post('/kios/snap-token', [BiometricController::class, 'getSnapToken']);
Route::post('/biometric/payment-progress', [BiometricController::class, 'reportPaymentProgress']);

// Endpoint Midtrans Callback (Webhook Web Notification)
Route::post('/midtrans/callback', [BiometricController::class, 'callback']);